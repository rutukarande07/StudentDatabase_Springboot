package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.entity.Student01;

public interface Student01Repository extends JpaRepository<Student01, Integer> {

}
