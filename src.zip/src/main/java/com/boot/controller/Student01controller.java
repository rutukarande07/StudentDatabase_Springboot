package com.boot.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Student01;
import com.example.repository.Student01Repository;

@RestController
public class Student01controller {
	
	@Autowired
	Student01Repository sr;
	
	@PostMapping("/savethestudent")
	public void saveStudent01(@RequestBody Student01 s) {
		System.out.println(s.getAge());
		sr.save(s);
		
	}
	
	@GetMapping("/getstudent")
	public Student01 getStudent01(@RequestParam int id) {
		Optional<Student01> os=sr.findById(id);
		Student01 s=os.get();
		return s;
		
	}
	
	@GetMapping("/getalldata")
	public List<Student01> getallStudent01(){
		List<Student01> os=sr.findAll();
		return os;
	}
	
	@PutMapping("/updatestudentdata")
	public void updateStudent01Data(@RequestBody Student01 s) {
		sr.save(s);
	}
	
	@DeleteMapping("/deletestudentdata")
	public String deleteStuden01(@RequestParam int id) {
		sr.deleteById(id);
		return "deleted succesfully";
	}
	
	

}
